<?php

$kata1 = "Topi";
$kata2 = "Bundar";

echo $kata1 . " " . "saya" . " $kata2" . ", " . $kata2 . " " . $kata1 . " " . "saya.";

?>