<?php

//buat variabel berisi angka 
$angka = 10;
echo "aku adalah angka $angka.<br>";

//operasi perkalian
$angka *=8;
echo "jika aku dikali 8, jumlahku sekarang $angka.<br>";

//operasi pembagian
$angka /=4;
echo "jika aku dibagi 4, jumlahku sekarang $angka.<br>";

//operasi pengurangan
$angka -=6;
echo "jika aku dikurang 6, jumlahku sekarang $angka.<br>";

//operasi penambahan
$angka +=2;
echo "jika aku dibagi ditambah 2, jumlahku sekarang $angka.<br>";

?>